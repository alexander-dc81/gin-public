package controllers

import (
	"github.com/revel/revel"
)

//Test1 ...
type Test1 struct {
	*revel.Controller
}

//Dashboard ...
func (c Test1) Dashboard() revel.Result {

	return c.RenderTemplate("Plugins/html/3fc198ac-1559-492b-ab2f-ff9be488be71/Test1/dashboard.html")
}
